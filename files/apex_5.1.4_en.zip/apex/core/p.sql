set define '^' verify off
prompt ...p
create or replace procedure p wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
1df 148
PySktRSwPuir/a3q2cinKtaJ5KMwg2Npr+UVfC/PwT+VGYOsXY9cjpuK37IUBcgap0GspV2o
MBYc5D8Lun4oGFvBS5Hf2UeKq7q7LRFW5iiIL0fINltI/pTE9hZLXfCbZ/AJCjYi3TZiKjma
iOTy6fHxRrvCGsOwyB2/+gzkUcgh7IVl0RtVj5m85uztTMFUQ7KCkwUc5ib83xbcrJW8gKQh
e8ZEyd5ySMbZOpbSxrVeV0xk3kEgyZRtvC0hKsgYfVf3LSINDCZ8EThYZyQvhfGVvER+v2cK
XT2ohnKs0RfogrIdhtrJEhp8E0/aB2wX1g==

/
show errors
